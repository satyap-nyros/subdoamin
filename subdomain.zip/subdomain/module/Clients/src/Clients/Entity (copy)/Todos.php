<?php

namespace Clients\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Todos
 *
 * @ORM\Table(name="todos")
 * @ORM\Entity
 */
class Todos
{
    /**
     * @var integer
     *
     * @ORM\Column(name="td_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    public $tdId;

    /**
     * @var string
     *
     * @ORM\Column(name="todo", type="string", length=50, nullable=false)
     */
    public $todo;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="crted_date", type="datetime", nullable=true)
     */
    public $crtedDate;

    /**
     * @var integer
     *
     * @ORM\Column(name="pj_id", type="integer", nullable=false)
     */
    public $pjId;

    /**
     * @var integer
     *
     * @ORM\Column(name="uid", type="integer", nullable=false)
     */
    public $uid;

    /**
     * @var string
     *
     * @ORM\Column(name="status", type="string", length=20, nullable=true)
     */
    public $status;

    /**
     * Set Defaults
     *
     * @return todo
     */
    public function setDefaults($data)
    {
	
        $this->todo = $data->todos->title;
 	$this->crtedDate = new \DateTime();
	$this->pjId = $data->pjid;	
	$this->uid = $data->uid;
	$this->status = $data->todos->completed;	
	
        return $this;
    }



}
