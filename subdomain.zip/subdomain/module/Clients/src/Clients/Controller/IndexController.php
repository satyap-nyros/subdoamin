<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Clients\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
/*use Zend\Mail\Message;
use Zend\Mime;
use Zend\Mail\Transport\Smtp as SmtpTransport;
use Zend\Mail\Transport\SmtpOptions;*/
use Zend\Mail\Message;
use Zend\Mail\Transport\Smtp as SmtpTransport;
use Zend\Mail\Transport\SmtpOptions;
use Zend\Mime\Mime;
use Zend\Mime\Part as MimePart;
use Zend\Mime\Message as MimeMessage;

class IndexController extends AbstractActionController
{
    
    public function indexAction()
    {
	$user_session = new Container('user');
	$qb = $this->objectManager()->createQueryBuilder();
	$qb->add('select', 'u')->add('from', 'Clients\Entity\Users u')->add('where', 'u.id = ?1')->setParameter(1,$user_session->uid);
	$q = $qb->getQuery();	
        $info = $q->getResult();
        return new ViewModel(array('userinfo'=>$info[0]));
    } 

    public function email($to,$from,$bdy,$sub,$att)
    {
	/*$to = "prattipati.satyanarayana@gmail.com";
	$from = "satyanarayanap.nyros@gmail.com";
	$sub = "test";

	// first create the parts
$text = new Mime\Part();
$text->type = Mime\Mime::TYPE_TEXT;
$text->charset = 'utf-8';

$fileContents = fopen('/var/www/subdomain/public/upload_files/4_20140714022117.jpg');
$attachment = new Mime\Part($fileContent);
$attachment->type = 'image/jpg';
$attachment->filename = 'image-file-name.jpg';
$attachment->disposition = Mime\Mime::DISPOSITION_ATTACHMENT;

// then add them to a MIME message
$mimeMessage = new Mime\Message();
//$mailMessage->getHeaders()->get('content-type')->setType('multipart/alternative');
$mimeMessage->setParts(array($text, $attachment));	

	$message = new Message();
	$message->addTo($to)->addFrom($from)->setSubject($sub)->setBody($mimeMessage);

	// Setup SMTP transport using LOGIN authentication
	$transport = new SmtpTransport();
	$options   = new SmtpOptions(array(
	    'name'              => 'localhost',
	    'host'              => 'smtp.gmail.com',
	    'connection_class'  => 'login',
	    'connection_config' => array(
		'ssl'       => 'tls',
		'username' => 'satyanarayanap.nyros@gmail.com',
		'password' => 'm92jc93s',
	    ),
	   
	));
	$transport->setOptions($options);
	$transport->send($message);*/







	$content  = new MimeMessage();
        $htmlPart = new MimePart($bdy);
        $htmlPart->type = 'text/html';
        $textPart = new MimePart("Sorry, I'm going to be late today!");
        $textPart->type = 'text/plain';
        $content->setParts(array($textPart, $htmlPart));

        $contentPart = new MimePart($content->generateMessage());        
        $contentPart->type = 'multipart/alternative;' . PHP_EOL . ' boundary="' . $content->getMime()->boundary() . '"';

        $attachment = new MimePart(fopen($att,'r'));
        $attachment->type = mime_content_type ($att);
	$attachment->filename = basename ($att);
        $attachment->encoding    = Mime::ENCODING_BASE64;
        $attachment->disposition = Mime::DISPOSITION_ATTACHMENT;



        $body = new MimeMessage();
        $body->setParts(array($contentPart, $attachment));

        $message = new Message();
        $message->setEncoding('utf-8')
        ->addTo($to)
        ->addFrom($from)
        ->setSubject($sub)
        ->setBody($body);

        $transport = new SmtpTransport();
        $options   = new SmtpOptions(array(
	    'name'              => 'localhost',
	    'host'              => 'smtp.gmail.com',
	    'connection_class'  => 'login',
	    'connection_config' => array(
		'ssl'       => 'tls',
		'username' => 'satyanarayanap.nyros@gmail.com',
		'password' => 'm92jc93s',
	    ),
	   
	));
        $transport->setOptions($options);
        $transport->send($message);
	
      }
	   
  
    public function projectsAction()
    {
	$user_session = new Container('user');
	$qb = $this->objectManager()->createQueryBuilder();
	$qb->add('select', 'u')->add('from', 'Clients\Entity\Projects u')->add('where', 'u.usergroup = ?1 AND u.status =?2')->setParameter(1,$user_session->ugroup)->setParameter(2,1);
	$q = $qb->getQuery();
        $info = $q->getArrayResult();
	$pjs = array();$threads = array();
	for($i=0;$i<count($info);$i++)
	{
		if($info[$i]['type'] == 1)
		{
			$pjs[$i]['name'] = $info[$i]['name'];
			$pjs[$i]['id'] = $info[$i]['pjId'];
			$qb = $this->objectManager()->createQueryBuilder();
			$qb->add('select', 'u')->add('from', 'Clients\Entity\Todos u')->add('where', 'u.pjId = ?1')->setParameter(1,$pjs[$i]['id']);
			$q = $qb->getQuery();
        		$threads[$pjs[$i]['name']] = $q->getArrayResult();
			
		}
		else
		{
			$arr = explode(',',substr($info[$i]['users'],0,-1));
			for($j=0;$j<count($arr);$j++)
			{
				if($user_session->uid == $arr[$j])
				{
					$pjs[$i]['name'] = $info[$i]['name'];
					$pjs[$i]['id'] = $info[$i]['pjId'];
					$qb = $this->objectManager()->createQueryBuilder();
					$qb->add('select', 'u')->add('from', 'Clients\Entity\Todos u')->add('where', 'u.pjId = ?1')->setParameter(1,$pjs[$i]['id']);
					$q = $qb->getQuery();
					$threads[$pjs[$i]['name']] = $q->getArrayResult();
				}
			}			
		}
			
	}
	
	 return new ViewModel(array('projects'=>$pjs,'threads'=>$threads));
    }

    public function todosAction()
    {
	

	$id = $this->getEvent()->getRouteMatch()->getParam('id');
	$postdata = file_get_contents("php://input");	
	$data = json_decode($postdata);
	if($data)
	{
		if($data->todos->completed)
		{
			$data->todos->completed = 1;
		}
		else
		{
			$data->todos->completed = 0;
		}
		
		if($data->pjid)
		{
		$user_session = new Container('user');
		$data->uid = $user_session->uid;
		$todo = new \Clients\Entity\Todos();
		$todo->setDefaults($data);	    				  
	    	$this->objectManager()->persist($todo);
	   	$this->objectManager()->flush();
		$info = $todo->getTdId();
		}
		else
		{
		$info = 0;
		}
		echo json_encode($info);exit;
	}
	return new ViewModel(array('id'=>$id));
    }

    public function gettodosAction()
    {	
	if($_POST['pjid'])
	{
	$connection = $this->objectManager()->getConnection();
	$statement = $connection->prepare("SELECT  todo as title,status as completed,td_id FROM todos WHERE pj_id = :id");
	$statement->bindValue('id', $_POST['pjid']);
	$statement->execute();
	$results = $statement->fetchAll();
	
		echo json_encode($results);exit;
	}
    }

    public function updatetodoAction()
    {
	$postdata = file_get_contents("php://input");	
	$data = json_decode($postdata);
	
	if($data->todos->completed)
	{
		$data->todos->completed = 1;
	}
	else
	{
		$data->todos->completed = 0;
	}

	$qb = $this->objectManager()->createQueryBuilder();
	$q = $qb->update('Clients\Entity\Todos', 'u')
		->set('u.status','?2')
		->set('u.todo','?3')						
		->where('u.tdId = ?1')
		->setParameter(2, $data->todos->completed)
		->setParameter(3, $data->todos->title)			
		->setParameter(1, $data->todos->td_id)
		->getQuery();
		$p = $q->execute();
	echo json_encode($p);exit;
    }

    public function updtalltodosAction()
    {
	$postdata = file_get_contents("php://input");	
	$data = json_decode($postdata);
	if($data->markall == 2)
	{
		$data->markall = 1;
	}
	else
	{
		$data->markall = 0;
	}
	$qb = $this->objectManager()->createQueryBuilder();
	$q = $qb->update('Clients\Entity\Todos', 'u')
		->set('u.status','?2')							
		->where('u.pjId = ?1')
		->setParameter(2, (int)$data->markall)				
		->setParameter(1, (int)$data->pjid)
		->getQuery();
		$p = $q->execute();
	echo json_encode($p);exit;
    }


    public function deletetodoAction()
    {
	$postdata = file_get_contents("php://input");	
	$data = json_decode($postdata);
	$query = $this->objectManager()->createQuery("DELETE Clients\Entity\Todos u WHERE u.tdId = ".(int)$data->todos->td_id."");
	echo $query->getResult();exit;	
    }

    public function msgspertodoAction()
    {
	
	$postdata = file_get_contents("php://input");	
	$data = json_decode($postdata);
	$qb = $this->objectManager()->createQueryBuilder();
	$qb->add('select', 'u')->add('from', 'Clients\Entity\Messages u')->add('where', 'u.tdId = ?1')->setParameter(1,$data->todoId);
	$q = $qb->getQuery();	
        $info = $q->getArrayResult();
	
	foreach($info as $key => $value)
	{
		$user_session = new Container('user');
		$info[$key]['uinfo'] = $this->getUser($value['uid']);
		
		
		if((int)$user_session->uid == (int)$value['uid'])
		{

			foreach($info[$key]['msgCrtDate'] as $key1 =>$val)
			{
			   if((strtotime(date('Y-m-d H:i:s')) * 1000 - strtotime($val) * 1000)/60000 <= 15)
			   {
				$info[$key]['uinfo']['shedit'] = 'yes';
			   }
			  break;
			}
			
		}
		
	}
	
	echo json_encode($info);
	exit;
	
    }

    public function getUser($uid)
    {
	
	$user_session = new Container('user');
	$qb = $this->objectManager()->createQueryBuilder();
	$qb->add('select', 'u')->add('from', 'Clients\Entity\Users u')->add('where', 'u.id = ?1')->setParameter(1,$uid);
	$q = $qb->getQuery();	
        $info = $q->getArrayResult();
	return $info[0];
    }

    public function thistodoAction()
    {
	
	$postdata = file_get_contents("php://input");	
	$data = json_decode($postdata);
	$data1 = $this->objectManager()->getRepository('Clients\Entity\Todos')->find($data->todoId);	
	echo json_encode($data1);exit;
    }

    public function updatemsgAction()
    {
	
	$uri = $this->getRequest()->getUri();
	$scheme = $uri->getScheme();
	$host = $uri->getHost();
	$base = sprintf('%s://%s', $scheme, $host);
	$temp = explode(".", $_FILES["file"]["name"]);
	$extension = end($temp);
	$user_session = new Container('user');

	$_POST['uid'] = $user_session->uid;
	$prercrd = $this->objectManager()->getRepository('Clients\Entity\Messages')->find((int)$_POST['msgId']);	
	if($extension)
	{
		
		$filename1 = $user_session->uid.'_'.date('Ymdhis').'.'.$extension;
		$_POST['filepath'] = $base."/upload_files/" . $filename1;
		if(!empty($prercrd->filePath))
		{
			$arr = explode('/',$prercrd->filePath);
			$filename = $arr[count($arr)-1];
			if (file_exists(getcwd()."/public/upload_files/".$filename)) {
				unlink(getcwd()."/public/upload_files/".$filename);
			}
		}
	
	
	move_uploaded_file($_FILES["file"]["tmp_name"],getcwd()."/public/upload_files/" . $filename1);
	
	}
	else
	{
		
		if($_POST['rmfile'] != "null")
		{
			$_POST['filepath'] = $prercrd->filePath;
			
		}
		else
		{
			$_POST['filepath'] = '';
			if(!empty($prercrd->filePath))
			{
				$arr = explode('/',$prercrd->filePath);
				$filename = $arr[count($arr)-1];
				if (file_exists(getcwd()."/public/upload_files/".$filename)) {
					unlink(getcwd()."/public/upload_files/".$filename);
				}
			}
		}	
		
	}

	$qb = $this->objectManager()->createQueryBuilder();
	$q = $qb->update('Clients\Entity\Messages', 'u')
		->set('u.filePath','?2')
		->set('u.message','?3')	
		->set('u.msgUpdtDate','?4')					
		->where('u.msgId = ?1')
		->setParameter(2, $_POST['filepath'])
		->setParameter(3, $_POST['message'])
		->setParameter(4, new \DateTime())		
		->setParameter(1, $_POST['msgId'])
		->getQuery();
		$p = $q->execute();
	if($p)
	{
	$info['msginfo'] = $this->objectManager()->getRepository('Clients\Entity\Messages')->find((int)$_POST['msgId']);	
	$info['msginfo']->uinfo = $this->getUser($user_session->uid);
	}

	if($_POST['emailslist'])
	{

	    $todoinfo = $this->objectManager()->getRepository('Clients\Entity\Todos')->find((int)$_POST['tdid']);
	 $pjinfo = $this->objectManager()->getRepository('Clients\Entity\Projects')->find((int)$_POST['pjId']);
		$arr = explode(',',substr($_POST['emailslist'],0,-1));
		
		if($_POST['filepath'])
		{
			$att = getcwd()."/public/upload_files/" . basename ($_POST['filepath']);
		}
		else
		{
			$att = '';
		}
		
		for($i=0;$i<count($arr);$i++)
		{
			$this->email($arr[$i],$info['msginfo']->uinfo['email'],$_POST['message'],"[".$pjinfo->name."] ".$todoinfo->todo,$att);
		}
	}
	
	echo json_encode($info);exit;

    }

    public function savemsgAction()
    {
	
	
	$uri = $this->getRequest()->getUri();
	$scheme = $uri->getScheme();
	$host = $uri->getHost();
	$base = sprintf('%s://%s', $scheme, $host);
	$temp = explode(".", $_FILES["file"]["name"]);
	$extension = end($temp);
	$user_session = new Container('user');
	$_POST['uid'] = $user_session->uid;
	if($extension)
	{
	$filename = $user_session->uid.'_'.date('Ymdhis').'.'.$extension;
	$_POST['filepath'] = $base."/upload_files/" . $filename;
	move_uploaded_file($_FILES["file"]["tmp_name"],getcwd()."/public/upload_files/" . $filename);
	}
	else
	{
	$_POST['filepath'] = '';
	}
			
	$msg = new \Clients\Entity\Messages();
	$msg->setDefaults($_POST);    
    	$this->objectManager()->persist($msg);
   	$this->objectManager()->flush();
	$info['msginfo'] = $this->objectManager()->getRepository('Clients\Entity\Messages')->find($msg->getMsgId());	
	$info['msginfo']->uinfo = $this->getUser($user_session->uid);
	$info['msginfo']->uinfo['shedit'] = 'yes';
	if($_POST['emailslist'])
	{

	    $todoinfo = $this->objectManager()->getRepository('Clients\Entity\Todos')->find((int)$info['msginfo']->tdId);
	 $pjinfo = $this->objectManager()->getRepository('Clients\Entity\Projects')->find((int)$info['msginfo']->pjId);
		$arr = explode(',',substr($_POST['emailslist'],0,-1));
		if($filename)
		{
			$att = getcwd()."/public/upload_files/" . $filename;
		}
		else
		{
			$att = '';
		}
		for($i=0;$i<count($arr);$i++)
		{
			$this->email($arr[$i],$info['msginfo']->uinfo['email'],$_POST['message'],"[".$pjinfo->name."] ".$todoinfo->todo,$att);
		}
	}
	 	
	echo json_encode($info);exit;
    }

    public function fetchmsgAction()
    {
	$postdata = file_get_contents("php://input");	
	$data = json_decode($postdata);
	$user_session = new Container('user');
	
	$info['msginfo'] = $this->objectManager()->getRepository('Clients\Entity\Messages')->find((int)$data->msgId);	
	$info['msginfo']->uinfo = $this->getUser($user_session->uid);
	$info['msginfo']->uinfo['shedit'] = 'yes';
	echo json_encode($info);exit;
    }

    public function validatefileAction()
    {
	    $uri = $this->getRequest()->getUri();
	    $scheme = $uri->getScheme();
	    $host = $uri->getHost();
	    $base = sprintf('%s://%s', $scheme, $host);
	    
	if ($_FILES["file"]["size"] < 20000) {
	  if ($_FILES["file"]["error"] > 0) {
	    echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
	  } else {
		$user_session = new Container('user');
	    
	    $temp = explode(".", $_FILES["file"]["name"]);
		$extension = end($temp);
		$filename = $user_session->uid.'_'.date('Ymdhis').'.'.$extension;
		
	    if (file_exists(getcwd()."/public/upload_files/".$filename)) {
	      $msg = $_FILES["file"]["name"] . " already exists. ";
	    } else {
	     
		$msg=1;		
	    }
	  }
	} else {
		
	   $msg = 'File exceeds it size limit'; 
	}
	echo json_encode($msg);exit;
	
    }


     public function objectManager()
     {
	return ($this
        ->getServiceLocator()
        ->get('Doctrine\ORM\EntityManager'));
     }

    public function getemailsAction()
    {
        $postdata = file_get_contents("php://input");	
	$data = json_decode($postdata);
	$qb = $this->objectManager()->createQueryBuilder();
	$qb->add('select', 'u')->add('from', 'Clients\Entity\Projects u')->add('where', 'u.pjId = ?1 AND u.status = ?2')->setParameter(1,(int)$data->pjId)->setParameter(2,1);
	$q = $qb->getQuery();
        $info = $q->getArrayResult();
	$connection = $this->objectManager()->getConnection();
	if($info[0]['users'])
	{
		$usrs = substr($info[0]['users'],0,-1);
		$statement = $connection->prepare("SELECT * FROM users where user_group = '".$info[0]['usergroup']."' AND status=1 AND id IN (".$usrs.")");
	}
	else
	{
		$statement = $connection->prepare("SELECT * FROM users where user_group = '".$info[0]['usergroup']."' AND status=1");
	}	
	$statement->execute();
	$results = $statement->fetchAll();
	echo json_encode($results);exit;
    }
     
}
