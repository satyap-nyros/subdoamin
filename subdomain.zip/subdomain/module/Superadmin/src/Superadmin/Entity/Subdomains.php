<?php
 
namespace Superadmin\Entity;
 
use Doctrine\ORM\Mapping as ORM;
 
/** @ORM\Entity */
class subdomains {
 
    /**
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @ORM\Column(type="integer")
     */
    public $sd_id;
 
    /** @ORM\Column(type="string", length=15) */
    public $subdomain;

    /** @ORM\Column(type="string", length=50) */
    public $email;

    /** @ORM\Column(type="integer", length=2) */
    public $status;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId() {
        return $this->ID;
    }


   /**
     * Set row
     *
     * @param string $fullname
     * @return User
     */
    public function setRow($data) {
	
        $this->subdomain = $data['subdomain']; 	
	$this->email = $data['email'];	
	$this->status = $data['status'];	
        return $this;
    }  
 
}
