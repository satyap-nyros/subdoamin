<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Superadmin\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;

class IndexController extends AbstractActionController
{

    
    public function indexAction()
    {
	
	$cntrl = $this->getEvent()->getRouteMatch()->getParam('__CONTROLLER__');//class name
	$module = $this->getEvent()->getRouteMatch()->getMatchedRouteName(); //module name
	$action = $this->getEvent()->getRouteMatch()->getParam('action'); //action name	
        return new ViewModel(array('contrlr'=>$cntrl,'module'=>$module,'action'=>$action));
    }
    public function addAction()
    {	
	
	$postdata = file_get_contents("php://input");
	$data = json_decode($postdata);
	
	if($data->subdomain)
	{
	
		
		$query = $this->objectManager()->createQuery("SELECT s.subdomain FROM Superadmin\Entity\Subdomains s WHERE s.subdomain = '".$data->subdomain."'");
		$subdomain = $query->getResult();
		if(!$subdomain)
		{
			$res = new \Superadmin\Entity\Subdomains();
			$res->setRow((array)$data);    			
    			$this->objectManager()->persist($res);
   	 		$this->objectManager()->flush();
			$dbres = $this->createDb($data->subdomain,$data->email);
			$result = $dbres;
		}
		else
		{
			$result = 7;
		}
		echo json_encode($result);exit;
		
	}
	
	return new ViewModel();
    }
    
    public function domainsAction()
    {
	$info = $this->objectManager()->getRepository("Superadmin\Entity\Subdomains")->findAll();	
	return new ViewModel(array('dns' => $info));
    }

 

 
     public function objectManager()
     {
	return ($this
        ->getServiceLocator()
        ->get('Doctrine\ORM\EntityManager'));
     }

     public function configDb()
     {
		$link = mysql_connect('localhost', 'root', 'root');
		if (!$link) {
		    die('Could not connect: ' . mysql_error());
			}
		return $link;
     }
    public function getthisdomainAction()
     {
	$postdata = file_get_contents("php://input");	
	$data = json_decode($postdata);
	$userinfo = $this->objectManager()->find('Superadmin\Entity\Subdomains', $data->id);
	echo json_encode($userinfo );exit;
     }
    public function editAction()
    {
	$postdata = file_get_contents("php://input");	
	$data = json_decode($postdata);	
	if($data->subdomain)
	{			
		
	 	$qb = $this->objectManager()->createQueryBuilder();
		$qb->add('select', 'u')->add('from', 'Superadmin\Entity\Subdomains u')->add('where', 'u.subdomain = ?1 AND u.sd_id != ?2')->setParameters(array(1=>$data->subdomain,2=>$data->sd_id));
		$q = $qb->getQuery();
        	$row = $q->getArrayResult();
		if(!$row)
		{
			$pre_info = $this->objectManager()->find('Superadmin\Entity\Subdomains', $data->sd_id);
			$qb = $this->objectManager()->createQueryBuilder();
			$q = $qb->update('Superadmin\Entity\Subdomains', 'u')
			->set('u.subdomain','?2')
			->set('u.email','?3')			
			->set('u.status','?4')								
			->where('u.sd_id = ?1')
			->setParameter(2, $data->subdomain)
			->setParameter(3, $data->email)
			->setParameter(4, $data->status)
			->setParameter(1, $data->sd_id)
			->getQuery();
			$p = $q->execute();			
			$dbres = $this->updateDb($pre_info,$data->subdomain,$data->email);
			$res = $dbres;
		}
		else
		{
			$res = 'Subdomain already existed';
		}
		echo json_encode($res);exit;
	}
	$id = $this->getEvent()->getRouteMatch()->getParam('id');
	return new ViewModel(array('id' => $id));
    }

    public function updateDb($pre_data,$dbname,$email)
    {
	$link = $this->configDb();
	if($link)
	{
	    $new_db_name = 'host_'.$dbname;
	    $crtdb_sql = "CREATE database $new_db_name";
	    if(mysql_query($crtdb_sql))
	    {
		$old_dbname = 'host_'.$pre_data->subdomain;	
		    $sql = "SHOW TABLES FROM $old_dbname";
		    $result = mysql_query($sql);
		    while ($row = mysql_fetch_row($result))
		    {
			$clone_tabs_sql ="CREATE TABLE $new_db_name.$row[0] SELECT * FROM $old_dbname.$row[0]";
			if(mysql_query($clone_tabs_sql))
	    		{
			   if($row[0] == 'users')
			   {
				mysql_select_db($new_db_name,$link);
			   	//$update_sql = "UPDATE users SET username="$dbname.'user'",email=$email WHERE id=1";
				$update_sql = "UPDATE users SET username='$dbname.user',password='$dbname',email='$email' WHERE id=1";
				if(mysql_query($update_sql))
				{
				    if(mysql_query("DROP database $old_dbname"))
				    {
					return "Subdomain successfully updated";
				    }
				    else
				    {
					return "Unable to drop previous DB";
				    }					
				}
				else
				{
					return 'We did not find default subdomain administrater';
				}			
			   }
			   
			}
			else
			{
			    return 'Error during copy tables into new DB';
			}
		    }
		
	    }
	    else
	    {
		mysql_select_db($new_db_name,$link);
		$update_sql = "UPDATE users SET username='$dbname.user',password='$dbname',email='$email' WHERE id=1";
		if(mysql_query($update_sql))
		{
		    return "Subdomain successfully updated";
		}
		else
		{
		    return "Subdomain update failed"; 
		}
	    }
	    
	   // return $sql = 'RENAME TABLE le TO new_db.table';
	}
	else
	{
		return "Error while creating DB";
	}
    }

     public function createDb($dbname,$email)
	{
		$link = $this->configDb();
		if($link)
		{
			$sql = 'CREATE DATABASE host_'.$dbname.'';
			if (mysql_query($sql, $link)) 
			{			   
				mysql_select_db('host_'.$dbname,$link);
				$sql1 = 'CREATE TABLE users (id MEDIUMINT NOT NULL AUTO_INCREMENT,username VARCHAR(20) NOT NULL,password VARCHAR(20) NOT NULL,email VARCHAR(50) NOT NULL,role INT(2) NOT NULL,first_name VARCHAR(20) NOT NULL,last_name VARCHAR(20) NOT NULL,user_group VARCHAR(10) NOT NULL,status INT(1) NOT NULL,mobile VARCHAR(15) NOT NULL,profile_pic VARCHAR(50) NOT NULL,PRIMARY KEY (id))';
				
				if (mysql_query($sql1,$link)) 
				{
				$sql2 = "INSERT INTO users (username,password,email,role) VALUES('".$dbname.".user','".$dbname."','".$email."',1)";
					if(mysql_query($sql2,$link))
					{
						return 4;
					}
					else
					{
						return 5;
					}
				}
				else
				{
					return 6;
				}		   
			} else {
			    return 1;
			}
		}
		else
		{
			return 2;
		}			
	}

	public function deleteAction()
	{
		if(!empty($_POST['sd_id']))
		{
			$query = $this->objectManager()->createQuery("DELETE Superadmin\Entity\Subdomains u WHERE u.sd_id = ".(int)$_POST['sd_id']."");
			if($query->getResult())
			{
				$dbname = 'host_'.$_POST['subdomain'];
				$res = $this->purgedb($dbname);
				
			}
			else
			{
				$res = 'DB Error';
			}
			echo $res;exit;
		}
	}

	public function purgedb($dbname)
	{
		$link = $this->configDb();
		if($link)
		{
			if(mysql_query("DROP database $dbname"))
			{
				return 'Subdomain successfully deleted';
		        }
			else
			{
				return 'Unable to delete DB';
			}			
		}
		return 'Connection Error';
	}

     
    
}
