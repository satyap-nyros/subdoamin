<?php
 
namespace Login\Entity;
 
use Doctrine\ORM\Mapping as ORM;
 
/** @ORM\Entity */
class users {
 
    /**
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @ORM\Column(type="integer")
     */
    public $id;
 
    /** @ORM\Column(type="string",length=20) */
    public $username;

    /** @ORM\Column(type="string",length=20) */
    public $password;

    /** @ORM\Column(type="string",length=20) */
    public $first_name;

    /** @ORM\Column(type="string",length=50) */
    public $email;

    /** @ORM\Column(type="string",length=20) */
    public $last_name;

    /** @ORM\Column(type="string",length=10) */
    public $user_group;

    /** @ORM\Column(type="smallint") */
    public $role;

    /** @ORM\Column(type="smallint") */
    public $status;

    /** @ORM\Column(type="string",length=15) */
    public $mobile;

    /** @ORM\Column(type="string",length=50) */
    public $profile_pic; 
 
}
