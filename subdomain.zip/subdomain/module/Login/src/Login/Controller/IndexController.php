<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonLogin for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Login\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;


class IndexController extends AbstractActionController
{
    protected $usersTable;

    public function indexAction()
    {
	$pieces = explode(".", $_SERVER['HTTP_HOST']);
	$link = mysql_connect('localhost', 'root', 'root');
	$db_list = mysql_list_dbs($link);

	$i = 0;$j = 0;
	$cnt = mysql_num_rows($db_list);
	while ($i < $cnt) {
	    if(mysql_db_name($db_list, $i)=='host_'.$pieces[0])
	    {
		$j++;
	    }
	    $i++;
	}

	/*$conn = array(
	    'driver'   => 'pdo_mysql',
	    'user'     => 'root',
	    'password' => 'root',
	    'dbname'   => 'host_nyros2'
	);

	$new = \Doctrine\ORM\EntityManager::create(
	    $conn,
	    $this->objectManager()->getConfiguration(),
	    $this->objectManager()->getEventManager()
	);*/
	
	if($j == 1)
	{
			$sql1 = 'CREATE TABLE projects (pj_id MEDIUMINT NOT NULL AUTO_INCREMENT,name VARCHAR(50) NOT NULL,usergroup VARCHAR(20) NOT NULL,type MEDIUMINT NOT NULL,users text,mail_clients text,status MEDIUMINT,pj_crt_date datetime,PRIMARY KEY (pj_id))';
		mysql_select_db('host_'.$pieces[0],$link);
		if(mysql_query($sql1))
		{
			$sql2 = 'CREATE TABLE todos (td_id MEDIUMINT NOT NULL AUTO_INCREMENT,todo VARCHAR(50) NOT NULL,crted_date datetime,pj_id MEDIUMINT NOT NULL,uid MEDIUMINT NOT NULL,status SMALLINT NOT NULL,PRIMARY KEY (td_id))';
			if(mysql_query($sql2))
			{
				$sql3 = 'CREATE TABLE messages (msg_id MEDIUMINT NOT NULL AUTO_INCREMENT,message text NOT NULL,msg_crt_date datetime,msg_updt_date datetime,td_id MEDIUMINT NOT NULL,pj_id MEDIUMINT NOT NULL,uid MEDIUMINT NOT NULL,file_path text,PRIMARY KEY (msg_id))';
				if(mysql_query($sql3))
				{
					
				}
			}
			
		}
		else
		{
			
			//echo mysql_error();exit;
		}
	}
        return new ViewModel(array('org'=>$pieces[0]));
    }

    public function validateAction()
   {
	
	$postdata = file_get_contents("php://input");
	$uname = json_decode($postdata);	
	$invalid = preg_match('/[^A-Za-z0-9.#\\-$]/', $uname->username);
	if($invalid)
	{
		$res['invalidChars'] = 1;
		$res['invalidChars'];
	}
	else
	{
		$res['success'] = 'valid';
	}
	echo json_encode($res);exit;
   }

  

   public function authenticateAction()
   {

	$postdata = file_get_contents("php://input");
	$data = json_decode($postdata);
	
	$qb = $this->objectManager()->createQueryBuilder();
	$qb->add('select', 'u')->add('from', 'Login\Entity\Users u')->add('where', 'u.username = ?1 AND u.password = ?2')->setParameters(array(1=>$data->username,2=>$data->password));
	$q = $qb->getQuery();
        $user = $q->getArrayResult();
	
	if($user)
	{
		$user_session = new Container('user');
		
		$user_session->uname = $user[0]['username'];
		$user_session->utype = $user[0]['role'];
		$user_session->uid = $user[0]['id'];	
		$user_session->ugroup = $user[0]['userGroup'];
		$result = $user[0];
	}
	else
	{
		$result =1;
	}
	
	echo json_encode($result);exit;
   }

    
     public function objectManager()
     {
	return ($this
        ->getServiceLocator()
        ->get('Doctrine\ORM\EntityManager'));
     }

    public function logoutAction()
    {
	
	$session = new Container('user');
        $session->getManager()->destroy();

	return $this->redirect()->toRoute('login', array(
                        'controller' => 'index',
                        'action' =>  'index'
		));
	
    }
    
}
