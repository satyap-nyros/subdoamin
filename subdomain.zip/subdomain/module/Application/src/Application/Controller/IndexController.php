<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;


class IndexController extends AbstractActionController
{
    

    public function indexAction()
    {
	$pieces = explode(".", $_SERVER['HTTP_HOST']);
	if(count($pieces)>2)
	{
		return $this->redirect()->toRoute('login', array(
                        'controller' => 'index',
                        'action' =>  'index'
		));
	}
	//$data = $this->objectManager()->getRepository('Application\Entity\Users')->findAll();
 	// print_r($data);exit;
   
    	$query = $this->objectManager()->createQuery("SELECT u.username FROM Application\Entity\Users u WHERE u.username = 'root'");
	
   // $query->setParameter('username','root');
    $users = $query->getResult();
	
    if(!count($users))
    {
	$user = new \Application\Entity\Users();
    	$user->setDefaults(array('username'=>'root','password'=>'root','user_nicename'=>'root',
		'email'=>'satyanarayanap_nyros@yahoo.com','user_url'=>'',
		'user_registered'=>date('Y-m-d H:m:s'),
		'user_activation_key'=>'','user_status'=>0,'display_name'=>'root'));
    
    	$this->objectManager()->persist($user);
   	 $this->objectManager()->flush();
    }
    
	
	//print_r($this->getEvent()->getRouteMatch()->getMatchedRouteName());exit;
        return new ViewModel();
    }

    public function validateAction()
   {
	
	$postdata = file_get_contents("php://input");
	$uname = json_decode($postdata);	
	$invalid = preg_match('/[^A-Za-z0-9.#\\-$]/', $uname->username);
	if($invalid)
	{
		$res['invalidChars'] = 1;
		$res['invalidChars'];
	}
	else
	{
		$res['success'] = 'valid';
	}
	echo json_encode($res);exit;
   }

  

   public function authenticateAction()
   {

	$postdata = file_get_contents("php://input");
	$data = json_decode($postdata);

	
	$query = $this->objectManager()->createQuery("SELECT u.username,u.ID FROM Application\Entity\Users u WHERE u.username = '".$data->username."' AND u.password = '".$data->password."'");
	
        //$query->setParameter('username','root');
    	$user = $query->getResult();
	
	if($user)
	{
		$user_session = new Container('user');
		
		$user_session->uname = $user[0]['username'];
		$user_session->utype = 3;
		$user_session->uid = $user[0]['ID'];	
		
		$result = 2;
	}
	else
	{
		$result =1;
	}
	echo json_encode($result);exit;
   }

   
	
     public function objectManager()
     {
	return ($this
        ->getServiceLocator()
        ->get('Doctrine\ORM\EntityManager'));
     }
	
    public function logoutAction()
    {
	
	$session = new Container('user');
        $session->getManager()->destroy();

	return $this->redirect()->toRoute('application', array(
                        'controller' => 'index',
                        'action' =>  'index'
		));
	
    }
    
}
