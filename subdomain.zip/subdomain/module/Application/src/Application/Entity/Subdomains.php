<?php
 
namespace Application\Entity;
 
use Doctrine\ORM\Mapping as ORM;
 
/** @ORM\Entity */
class subdomains {
 
    /**
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @ORM\Column(type="integer")
     */
    protected $sd_id;
 
    /** @ORM\Column(type="string", length=15) */
    protected $subdomain;

    /** @ORM\Column(type="string", length=50) */
    protected $email;

    /** @ORM\Column(type="integer", length=2) */
    protected $status;  
 
}
