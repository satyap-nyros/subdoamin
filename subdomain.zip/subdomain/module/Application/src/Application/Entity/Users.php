<?php
 
namespace Application\Entity;
 
use Doctrine\ORM\Mapping as ORM;
 
/** @ORM\Entity */
class users {
 
    /**
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @ORM\Column(type="integer")
     */
    protected $ID;
 
    /** @ORM\Column(type="string",length=60) */
    protected $username;

    /** @ORM\Column(type="string",length=64) */
    protected $password;

    /** @ORM\Column(type="string",length=50) */
    protected $user_nicename;

    /** @ORM\Column(type="string",length=100) */
    protected $email;

    /** @ORM\Column(type="string",length=100) */
    protected $user_url;

    /** @ORM\Column(type="string",length=60) */
    protected $user_registered;

    /** @ORM\Column(type="string",length=60) */
    protected $user_activation_key;

    /** @ORM\Column(type="smallint") */
    protected $user_status;

    /** @ORM\Column(type="string",length=250) */
    protected $display_name;

    /**
     * Get id
     *
     * @return integer
     */
    public function getId() {
        return $this->ID;
    }
 
    /**
     * Set fullname
     *
     * @param string $fullname
     * @return User
     */
    public function setDefaults($data) {
	
        $this->username = $data['username'];
 	$this->password = $data['password'];
	$this->user_nicename = $data['user_nicename'];
	$this->email = $data['email'];
	$this->user_url = $data['user_url'];
	$this->user_registered = $data['user_registered'];
	$this->user_activation_key = $data['user_activation_key'];
	$this->user_status = $data['user_status'];
	$this->display_name = $data['display_name'];
	
        return $this;
    }



	

 
 
}
