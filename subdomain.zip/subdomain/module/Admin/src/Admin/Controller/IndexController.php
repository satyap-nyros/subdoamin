<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;

class IndexController extends AbstractActionController
{
  
    public function indexAction()
    {	
	
	$user_session = new Container('user');
	
        return new ViewModel(array('userinfo'=>$user_session));
    }

    public function addprojectAction()
    {
	$postdata = file_get_contents("php://input");	
	$data = json_decode($postdata);
	if($data->usergroup)
	{
		$qb = $this->objectManager()->createQueryBuilder();
		$qb->add('select', 'u')->add('from', 'Admin\Entity\Users u')->add('where', 'u.role = 2 AND u.status = 1 AND u.user_group = ?1')->setParameter(1,$data->usergroup);
		$q = $qb->getQuery();
        	$rows = $q->getArrayResult();
		echo json_encode($rows);exit;
	}
	 return new ViewModel();
    }

    public function savenewpjctAction()
    {
	$postdata = file_get_contents("php://input");	
	$data = json_decode($postdata);
	if($data->name)
	{
		$qb = $this->objectManager()->createQueryBuilder();
		$qb->add('select', 'u')->add('from', 'Admin\Entity\Projects u')->add('where', 'u.name = ?1')->setParameter(1,$data->name);
		$q = $qb->getQuery();
        	$rows = $q->getArrayResult();
		if(!$rows)
		{
			$project = new \Admin\Entity\Projects();
			$project->setDefaults($data);	    				  
    			$this->objectManager()->persist($project);
   	 		$this->objectManager()->flush();
			$info = 1; 
		}
		else
		{
			$info = 2;
		}
		echo json_encode($info);exit;
	}
    }

    public function updatepjctAction()
    {
	$postdata = file_get_contents("php://input");	
	$data = json_decode($postdata);
	if($data->name)
	{
		$qb = $this->objectManager()->createQueryBuilder();
		$qb->add('select', 'u')->add('from', 'Admin\Entity\Projects u')->add('where', 'u.name = ?1 AND u.pjId != ?2')->setParameter(1,$data->name)->setParameter(2,$data->id);
		$q = $qb->getQuery();
        	$row = $q->getArrayResult();
		if(!$row)
		{
			$qb = $this->objectManager()->createQueryBuilder();
			$q = $qb->update('Admin\Entity\Projects', 'u')
			->set('u.name','?2')
			->set('u.usergroup','?3')
			->set('u.type','?4')			
			->set('u.status','?5')		
			->set('u.users','?6')					
			->where('u.pjId = ?1')
			->setParameter(2, $data->name)
			->setParameter(3, $data->usergroup)
			->setParameter(4, $data->type)
			->setParameter(5, $data->status)
			->setParameter(6, $data->users)
			->setParameter(1, $data->id)
			->getQuery();
			$p = $q->execute();
			$info = 3;
		}
		else
		{
			$info = 2;
		}
		echo json_encode($info);exit;
	}
    }

   public function projectsAction()
   {
	$allpjcts = $this->objectManager()->getRepository('Admin\Entity\Projects')->findAll(); 
	
	return new ViewModel(array('projects'=>$allpjcts));
   }

    public function addAction()
    {	
	$postdata = file_get_contents("php://input");
	
	$data = json_decode($postdata);
	
	
	if($data->username)
	{
		$qb = $this->objectManager()->createQueryBuilder();
		$qb->add('select', 'u')->add('from', 'Admin\Entity\Users u')->add('where', 'u.username = ?1 OR u.email = ?2')->setParameters(array(1=>$data->username,2=>$data->email));
		$q = $qb->getQuery();
        	$row = $q->getArrayResult();
		if($row)
		{
			$info = 2; 
		}
		else
		{
			$user = new \Admin\Entity\Users();
	    		$user->setDefaults($data);    
    			$this->objectManager()->persist($user);
   	 		$this->objectManager()->flush();
			$info = 3;
		}		
		echo json_encode($info);exit;
	}
	return new ViewModel();
    }

    public function getthisuserAction()
    {
	$postdata = file_get_contents("php://input");	
	$data = json_decode($postdata);
	$qb = $this->objectManager()->createQueryBuilder();
	$qb->add('select', 'u')->add('from', 'Admin\Entity\Users u')->add('where', 'u.id = ?1')->setParameter(1,$data->id);
	$q = $qb->getQuery();
        $userinfo = $q->getArrayResult();	
	echo json_encode($userinfo[0]);exit;
    }

    public function getthispjctAction()
    {
	$postdata = file_get_contents("php://input");	
	$data = json_decode($postdata);
	$qb = $this->objectManager()->createQueryBuilder();
	$qb->add('select', 'u')->add('from', 'Admin\Entity\Projects u')->add('where', 'u.pjId = ?1')->setParameter(1,$data->id);
	$q = $qb->getQuery();
        $pjinfo = $q->getArrayResult();	
	echo json_encode($pjinfo[0]);exit;
    }

    public function editAction()
    {
	$postdata = file_get_contents("php://input");	
	$data = json_decode($postdata);	
	if($data->username)
	{
		$qb = $this->objectManager()->createQueryBuilder();
		$qb->add('select', 'u')->add('from', 'Admin\Entity\Users u')->add('where', '(u.username = ?1 OR u.email = ?2) AND u.id != ?3')->setParameters(array(1=>$data->username,2=>$data->email,3=>$data->id));
		$q = $qb->getQuery();
        	$row = $q->getArrayResult();
		
		if($row)
		{
			$info = 1;	
		}
		else
		{
			$qb = $this->objectManager()->createQueryBuilder();
			$q = $qb->update('Admin\Entity\Users', 'u')
			->set('u.username','?2')
			->set('u.email','?3')
			->set('u.password','?4')
			->set('u.first_name','?5')
			->set('u.last_name','?6')
			->set('u.role','?7')
			->set('u.user_group','?8')
			->set('u.status','?9')
			->set('u.mobile','?10')
			->set('u.profile_pic','?11')						
			->where('u.id = ?1')
			->setParameter(2, $data->username)
			->setParameter(3, $data->email)
			->setParameter(4, $data->password)
			->setParameter(5, $data->first_name)
			->setParameter(6, $data->last_name)
			->setParameter(7, $data->role)
			->setParameter(8, $data->user_group)
			->setParameter(9, $data->status)
			->setParameter(10, $data->mobile)
			->setParameter(11, '')
			->setParameter(1, $data->id)
			->getQuery();
			$p = $q->execute();
			$info = 3;
		}
			
		echo json_encode($info);exit;
	}
	$id = $this->getEvent()->getRouteMatch()->getParam('id');	
	return new ViewModel(array('id' => $id));
    }

    public function editprojectAction()
    {
	$id = $this->getEvent()->getRouteMatch()->getParam('id');
	return new ViewModel(array('id' => $id));
    }

    public function deleteAction()
    {	
	$query = $this->objectManager()->createQuery("DELETE Admin\Entity\Users u WHERE u.id = ".(int)$_POST['id']."");
	echo $query->getResult();exit;
    }

    public function usersAction()
    {
	
	$qb = $this->objectManager()->createQueryBuilder();
	$qb->add('select', 'u')->add('from', 'Admin\Entity\Users u')->add('where', 'u.role = 2');
	$q = $qb->getQuery();
        $users = $q->getResult();	
	return new ViewModel(array('users'=>$users));
    }    

    public function objectManager()
     {
	return ($this
        ->getServiceLocator()
        ->get('Doctrine\ORM\EntityManager'));
     }
}
