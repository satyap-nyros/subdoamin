<?php

namespace Admin\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Projects
 *
 * @ORM\Table(name="projects")
 * @ORM\Entity
 */
class Projects
{
    /**
     * @var integer
     *
     * @ORM\Column(name="pj_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    public $pjId;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=50, nullable=false)
     */
    public $name;

    /**
     * @var string
     *
     * @ORM\Column(name="usergroup", type="string", length=20, nullable=false)
     */
    public $usergroup;

    /**
     * @var integer
     *
     * @ORM\Column(name="type", type="integer", nullable=false)
     */
    public $type;

    /**
     * @var string
     *
     * @ORM\Column(name="users", type="text", nullable=false)
     */
    public $users;

    /**
     * @var string
     *
     * @ORM\Column(name="mail_clients", type="text")
     */
    public $mailClients;

    /**
     * @var integer
     *
     * @ORM\Column(name="status", type="integer")
     */
    public $status;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="pj_crt_date", type="datetime")
     */
    public $pjCrtDate;



    /**
     * Get pjId
     *
     * @return integer 
     */
    public function getPjId()
    {
        return $this->pjId;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Projects
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set usergroup
     *
     * @param string $usergroup
     * @return Projects
     */
    public function setUsergroup($usergroup)
    {
        $this->usergroup = $usergroup;

        return $this;
    }

    /**
     * Get usergroup
     *
     * @return string 
     */
    public function getUsergroup()
    {
        return $this->usergroup;
    }

    /**
     * Set type
     *
     * @param integer $type
     * @return Projects
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return integer 
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set users
     *
     * @param string $users
     * @return Projects
     */
    public function setUsers($users)
    {
        $this->users = $users;

        return $this;
    }

    /**
     * Get users
     *
     * @return string 
     */
    public function getUsers()
    {
        return $this->users;
    }

    /**
     * Set mailClients
     *
     * @param string $mailClients
     * @return Projects
     */
    public function setMailClients($mailClients)
    {
        $this->mailClients = $mailClients;

        return $this;
    }

    /**
     * Get mailClients
     *
     * @return string 
     */
    public function getMailClients()
    {
        return $this->mailClients;
    }

    /**
     * Set status
     *
     * @param integer $status
     * @return Projects
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return integer 
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set pjCrtDate
     *
     * @param \DateTime $pjCrtDate
     * @return Projects
     */
    public function setPjCrtDate($pjCrtDate)
    {
        $this->pjCrtDate = $pjCrtDate;

        return $this;
    }

    /**
     * Get pjCrtDate
     *
     * @return \DateTime 
     */
    public function getPjCrtDate()
    {
        return $this->pjCrtDate;
    }


        /**
     * Set Defaults
     *
     * @return Projects
     */
    public function setDefaults($data)
    {
	
        $this->name = $data->name;
 	$this->usergroup = $data->usergroup;
	$this->type = $data->type;	
	$this->status = $data->status;
	$this->users = $data->users;	
	$this->mailClients = $data->mail_clients;
	$this->pjCrtDate = new \DateTime();
        return $this;
    }

 
}
