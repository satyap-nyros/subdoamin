<?php

namespace Admin\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Todos
 *
 * @ORM\Table(name="todos")
 * @ORM\Entity
 */
class Todos
{
    /**
     * @var integer
     *
     * @ORM\Column(name="td_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $tdId;

    /**
     * @var string
     *
     * @ORM\Column(name="todo", type="string", length=50, nullable=false)
     */
    private $todo;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="crted_date", type="datetime", nullable=true)
     */
    private $crtedDate;

    /**
     * @var integer
     *
     * @ORM\Column(name="pj_id", type="integer", nullable=false)
     */
    private $pjId;

    /**
     * @var integer
     *
     * @ORM\Column(name="uid", type="integer", nullable=false)
     */
    private $uid;



    /**
     * Get tdId
     *
     * @return integer 
     */
    public function getTdId()
    {
        return $this->tdId;
    }

    /**
     * Set todo
     *
     * @param string $todo
     * @return Todos
     */
    public function setTodo($todo)
    {
        $this->todo = $todo;

        return $this;
    }

    /**
     * Get todo
     *
     * @return string 
     */
    public function getTodo()
    {
        return $this->todo;
    }

    /**
     * Set crtedDate
     *
     * @param \DateTime $crtedDate
     * @return Todos
     */
    public function setCrtedDate($crtedDate)
    {
        $this->crtedDate = $crtedDate;

        return $this;
    }

    /**
     * Get crtedDate
     *
     * @return \DateTime 
     */
    public function getCrtedDate()
    {
        return $this->crtedDate;
    }

    /**
     * Set pjId
     *
     * @param integer $pjId
     * @return Todos
     */
    public function setPjId($pjId)
    {
        $this->pjId = $pjId;

        return $this;
    }

    /**
     * Get pjId
     *
     * @return integer 
     */
    public function getPjId()
    {
        return $this->pjId;
    }

    /**
     * Set uid
     *
     * @param integer $uid
     * @return Todos
     */
    public function setUid($uid)
    {
        $this->uid = $uid;

        return $this;
    }

    /**
     * Get uid
     *
     * @return integer 
     */
    public function getUid()
    {
        return $this->uid;
    }
}
