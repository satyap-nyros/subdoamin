<?php

namespace Admin\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Messages
 *
 * @ORM\Table(name="messages")
 * @ORM\Entity
 */
class Messages
{
    /**
     * @var integer
     *
     * @ORM\Column(name="msg_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $msgId;

    /**
     * @var string
     *
     * @ORM\Column(name="message", type="text", nullable=false)
     */
    private $message;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="msg_crt_date", type="datetime", nullable=true)
     */
    private $msgCrtDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="msg_updt_date", type="datetime", nullable=true)
     */
    private $msgUpdtDate;

    /**
     * @var integer
     *
     * @ORM\Column(name="td_id", type="integer", nullable=false)
     */
    private $tdId;

    /**
     * @var integer
     *
     * @ORM\Column(name="pj_id", type="integer", nullable=false)
     */
    private $pjId;

    /**
     * @var integer
     *
     * @ORM\Column(name="uid", type="integer", nullable=false)
     */
    private $uid;

    /**
     * @var string
     *
     * @ORM\Column(name="file_path", type="text", nullable=false)
     */
    private $filePath;



    /**
     * Get msgId
     *
     * @return integer 
     */
    public function getMsgId()
    {
        return $this->msgId;
    }

    /**
     * Set message
     *
     * @param string $message
     * @return Messages
     */
    public function setMessage($message)
    {
        $this->message = $message;

        return $this;
    }

    /**
     * Get message
     *
     * @return string 
     */
    public function getMessage()
    {
        return $this->message;
    }

    /**
     * Set msgCrtDate
     *
     * @param \DateTime $msgCrtDate
     * @return Messages
     */
    public function setMsgCrtDate($msgCrtDate)
    {
        $this->msgCrtDate = $msgCrtDate;

        return $this;
    }

    /**
     * Get msgCrtDate
     *
     * @return \DateTime 
     */
    public function getMsgCrtDate()
    {
        return $this->msgCrtDate;
    }

    /**
     * Set msgUpdtDate
     *
     * @param \DateTime $msgUpdtDate
     * @return Messages
     */
    public function setMsgUpdtDate($msgUpdtDate)
    {
        $this->msgUpdtDate = $msgUpdtDate;

        return $this;
    }

    /**
     * Get msgUpdtDate
     *
     * @return \DateTime 
     */
    public function getMsgUpdtDate()
    {
        return $this->msgUpdtDate;
    }

    /**
     * Set tdId
     *
     * @param integer $tdId
     * @return Messages
     */
    public function setTdId($tdId)
    {
        $this->tdId = $tdId;

        return $this;
    }

    /**
     * Get tdId
     *
     * @return integer 
     */
    public function getTdId()
    {
        return $this->tdId;
    }

    /**
     * Set pjId
     *
     * @param integer $pjId
     * @return Messages
     */
    public function setPjId($pjId)
    {
        $this->pjId = $pjId;

        return $this;
    }

    /**
     * Get pjId
     *
     * @return integer 
     */
    public function getPjId()
    {
        return $this->pjId;
    }

    /**
     * Set uid
     *
     * @param integer $uid
     * @return Messages
     */
    public function setUid($uid)
    {
        $this->uid = $uid;

        return $this;
    }

    /**
     * Get uid
     *
     * @return integer 
     */
    public function getUid()
    {
        return $this->uid;
    }

    /**
     * Set filePath
     *
     * @param string $filePath
     * @return Messages
     */
    public function setFilePath($filePath)
    {
        $this->filePath = $filePath;

        return $this;
    }

    /**
     * Get filePath
     *
     * @return string 
     */
    public function getFilePath()
    {
        return $this->filePath;
    }
}
