<?php

namespace Admin\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Projects
 *
 * @ORM\Table(name="projects")
 * @ORM\Entity
 */
class Projects
{
    /**
     * @var integer
     *
     * @ORM\Column(name="pj_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $pjId;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=50, nullable=false)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="usergroup", type="string", length=20, nullable=false)
     */
    private $usergroup;

    /**
     * @var integer
     *
     * @ORM\Column(name="type", type="integer", nullable=false)
     */
    private $type;

    /**
     * @var string
     *
     * @ORM\Column(name="users", type="text", nullable=false)
     */
    private $users;

    /**
     * @var string
     *
     * @ORM\Column(name="mail_clients", type="text", nullable=false)
     */
    private $mailClients;

    /**
     * @var integer
     *
     * @ORM\Column(name="status", type="integer", nullable=false)
     */
    private $status;

	/**
     * Get id
     *
     * @return integer
     */
    public function getId() {
        return $this->pj_id;
    }
 
    /**
     * Set Project
     *
     * @param string $fullname
     * @return project
     */
    public function setDefaults($data) {
	
  	$this->name = $data->name;
 	$this->usergroup = $data->usergroup;
	$this->type = $data->type;	
	$this->status = $data->status;
	$this->users = $data->users;	
	$this->mail_clients = '';
        return $this;
    }


}
