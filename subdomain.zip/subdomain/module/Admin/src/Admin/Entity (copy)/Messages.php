<?php

namespace Admin\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Messages
 *
 * @ORM\Table(name="messages")
 * @ORM\Entity
 */
class Messages
{
    /**
     * @var integer
     *
     * @ORM\Column(name="msg_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $msgId;

    /**
     * @var string
     *
     * @ORM\Column(name="message", type="text", nullable=false)
     */
    private $message;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="msg_crt_date", type="datetime", nullable=true)
     */
    private $msgCrtDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="msg_updt_date", type="datetime", nullable=true)
     */
    private $msgUpdtDate;

    /**
     * @var integer
     *
     * @ORM\Column(name="td_id", type="integer", nullable=false)
     */
    private $tdId;

    /**
     * @var integer
     *
     * @ORM\Column(name="pj_id", type="integer", nullable=false)
     */
    private $pjId;

    /**
     * @var integer
     *
     * @ORM\Column(name="uid", type="integer", nullable=false)
     */
    private $uid;

    /**
     * @var string
     *
     * @ORM\Column(name="file_path", type="text", nullable=false)
     */
    private $filePath;


}
