<?php

namespace Admin\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Todos
 *
 * @ORM\Table(name="todos")
 * @ORM\Entity
 */
class Todos
{
    /**
     * @var integer
     *
     * @ORM\Column(name="td_id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $tdId;

    /**
     * @var string
     *
     * @ORM\Column(name="todo", type="string", length=50, nullable=false)
     */
    private $todo;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="crted_date", type="datetime", nullable=true)
     */
    private $crtedDate;

    /**
     * @var integer
     *
     * @ORM\Column(name="pj_id", type="integer", nullable=false)
     */
    private $pjId;

    /**
     * @var integer
     *
     * @ORM\Column(name="uid", type="integer", nullable=false)
     */
    private $uid;


}
