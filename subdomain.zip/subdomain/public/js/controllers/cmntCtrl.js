/*global angular */

/**
 * The main controller for the app. The controller:
 * - retrieves and persists the model via the todoStorage service
 * - exposes the model to the template and provides event handlers
 */

angular.module('todomvc')
	.controller('CmntCtrl', function TodoCtrl($scope, $routeParams, $http,$resource,fileUpload) {
	'use strict';
	/*var test = $resource('/Clients/index/thistodo',{todoId : $routeParams.tdid},
		{
			show : {method : 'GET', params: {id: $routeParams.tdid}}
		});
	console.log(test.show());*/
		 $http.post('/clients/index/thistodo', {todoId : $routeParams.tdid})
				  .success(function(data) {
					$scope.todometa = data;					  
				  });
		$http.post('/clients/index/msgspertodo', {todoId : $routeParams.tdid})
				  .success(function(data) {
					
					$scope.messages = data;	
					
							  
				  });

		$http.post('/clients/index/getemails', {pjId : $('#pjid').text()})
				  .success(function(data) {
					
					$scope.pjemails = data;	
					
							  
				  });


	
		$scope.fname = null;	
		$scope.ext = null;
		$scope.grupemails = {};
		$scope.addTodo = function(){
			var fd = new FormData();

			if($scope.originalMsg)
			{				
				var uploadUrl = "/clients/index/updatemsg";
				fd.append('msgId', $scope.originalMsg.msgId);
				fd.append('rmfile', $scope.fname);
			}
			else
			{
				var uploadUrl = "/clients/index/savemsg";
			}
			var str = '';
			for(var key in $scope.grupemails)
			{
				if($scope.grupemails[key])
				{
					str = key + ',' + str ;
				}
			}
			
			var file = $scope.myFile;			
        		fd.append('file', file);
			fd.append('message', $scope.message);
			fd.append('pjId',  $('#pjid').text());
			fd.append('tdid', $scope.todometa.tdId);
			fd.append('emailslist', str);	
			
			fileUpload.uploadFileToUrl(fd, uploadUrl).then(function(response){
			
			if($scope.originalMsg)
			{
			if($scope.originalMsg.msgId)
			{
			
			$http.post('/clients/index/fetchmsg',{msgId : $scope.originalMsg.msgId })
				.success(function(data){						
					$scope.messages.push(data.msginfo);
					$scope.originalMsg = null;	
				})
				.error(function(){
				});
			}
			}
			else
			{
			$scope.messages.push(response.data.msginfo);
			}
			console.log(response.data.msginfo);
			});
			
			$('input[type="file"]').replaceWith($('input[type="file"]').val('').clone(true));
			$scope.message = '';
			$scope.fname = null;
			$scope.myFile = null;
		}

		$scope.cancel =function(){
			window.location = '/clients';
		}
		$scope.originalMsg = null;
		$scope.editmsg = function(msg){
			
			
			if($scope.originalMsg)
			{
			var premsg = $scope.originalMsg;			
			$scope.messages.push(premsg);
			}
			$scope.originalMsg = angular.extend({}, msg);
				
			$scope.messages.splice($scope.messages.indexOf(msg), 1);
			
			
			$scope.message = msg.message;
			$scope.editmessage = msg;
			if(msg.filePath)
			{
				var $t = msg.filePath;
				$t = $t.split('/');
				$scope.fname = $t[$t.length-1];				
				var $s = ($t[$t.length-1]).split('.');
				$scope.ext = $s[$s.length-1];
				
			}
			else
			{
				$scope.fname = null;	
				$scope.ext = null;
			}
			
		}

		$scope.hai = function(){
			alert('fruit')
		}
		
		
	
	});




angular.module('todomvc').directive('fileSelect',function ($parse,$http) {
var template = ' <input type="file"  file-model="myFile"  />';
    return {
       require: 'ngModel',
        link: function(scope, element, attrs, ctrl) {
           
            var selector = $( template );
	    element.append(selector);
	    var model = $parse('myFile');
            var modelSetter = model.assign;
	    selector.bind('change', function( event ) {
		ctrl.$setValidity('invalidFile', true);
		var fd = new FormData();
		
        	fd.append('file', event.originalEvent.target.files[0]);
		$http.post('/clients/index/validatefile',fd,
			{transformRequest: angular.identity,
            		headers: {'Content-Type': undefined}})
			.success(function(data) {
				alert(data)
				if(data == 1)
				{
				ctrl.$setValidity('invalidFile', true);
				
				}	
				else
				{
				
				ctrl.$setValidity('invalidFile', false);
				}			  
			  });
		
                scope.$apply(function(){
                    modelSetter(scope, event.originalEvent.target.files[0]);
                });		
            });
        }
    };
});

angular.module('todomvc').directive('filePath',function ($http) {

    return {       
        link: function(scope, element, attrs, ctrl) {
           	
		var listarr = attrs.filePath.split('.').pop();		
		if(listarr)
		{
			if((/\.(gif|jpg|jpeg|tiff|png)$/i).test(attrs.filePath))
			{
			   var template = ' <img  src='+ attrs.filePath +'  />';			   
			}
			else
			{
			    if(listarr == 'doc' || listarr == 'docx')listarr = 'doc';
			    else if(listarr == 'php')listarr = 'http';
			    var template = ' <img  src="/images/'+ listarr +'.png"  />';
			}
			
			var selector = $( template );
	    		   element.append(selector);
			   selector.bind('click', function( event ) {
				//alert('asd')
			   });		
		}
		else
		{
		
		}
		
        }
    };
});

angular.module('todomvc').service('fileUpload', function ($http) {
    this.uploadFileToUrl = function(fd, uploadUrl){
	
       return $http.post(uploadUrl, fd,{
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}})
        .success(function(data){
		console.log(data);
		return data;		
        })
        .error(function(){
        });
    }
});



		
