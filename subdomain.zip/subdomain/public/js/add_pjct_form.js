


var app = angular.module('myApp', []);

// http://stackoverflow.com/questions/12864887/angularjs-integrating-with-server-side-validation





//Form submitting

app.controller('FormCtrl', function ($scope, $http) {

	$scope.usergroup = "PHP";
	$scope.type = 1;

	$scope.value = [];
	
   $scope.updateQuestionValue = function(choice){	
	if($("input[type='checkbox'][name='group_one[]']:checked").length)
	{
		$scope.value = $scope.value.push(1);
	}
	else
	{
		$scope.value = [];
	}  
    };

	$scope.users = {};
  $scope.addProject = function() {
	if($scope.status)
	{
		$scope.status = 1;
	}
	else
	{
		$scope.status = 0;
	}
	var formData = { 'name' : $scope.name,
                	'usergroup' : $scope.usergroup,                	
                	'type' : $scope.type,                	
			'status' : $scope.status,
			'mail_clients' : ''
			};
	
	if($scope.type == 2)
	{
		var str='';
		for (var key in $scope.users) {
			if($scope.users[key])
			{
				str = key+','+str;
			}
		    }
		formData.users = str;
		/*Object.size = function(obj) {
		    var size = 0, key;
		    for (key in obj) {
			if (obj.hasOwnProperty(key)) size++;
		    }
		    return size;
		};

		// Get the size of an object
		var size = Object.size($scope.users);*/
	}

	
    $http({
        url: "/admin/index/savenewpjct",
        data: formData,
        method: 'POST'
      }).success(function(data){
		console.log(data)
        if(data == 2)
	{
		$scope.error = "Project Name already existed";
		$scope.success = "";
	}
	else
	{
		$scope.error = "";
		$scope.success = "Project inserted successfully";
	}
	
      }).error(function(err){"ERR", console.log(err)})
  };

});



/*app.directive('match', [function () {
  return {
    require: 'ngModel',
    link: function (scope, elem, attrs, ctrl) {
	alert(attrs.ngRequired);
        
      scope.$watch('[' + attrs.ngModel + ', ' + attrs.match + ']', function(value){
        ctrl.$setValidity('match', value[0] === value[1] );
      }, true);

    }
  }
}]);*/

app.directive('listshow', ['$http',function ($http) {
  return {
    require: 'ngModel',
    link: function (scope, elem, attrs, ctrl) {
    scope.$watch('type', function(value) {
			
		if(value == 2)
		{
			ctrl.$setValidity('match', true );
			$http({
				url: "/admin/index/addproject",
				data: {'usergroup':scope.usergroup},
				method: 'POST'
			      }).success(function(data){
				
					scope.userslist = data;
					
				});
			scope.isselected = true;
		}
		else
		{
			scope.userslist = null;
			scope.isselected = false;
		}
	});

    }
  }
}]);


app.directive('groupshow', ['$http',function ($http) {
  return {
    require: 'ngModel',
    link: function (scope, elem, attrs, ctrl) {
    scope.$watch('usergroup', function(value) {
		$http({
				url: "/admin/index/addproject",
				data: {'usergroup':scope.usergroup},
				method: 'POST'
			      }).success(function(data){
				
					scope.userslist = data;
					
				});
	});

    }
  }
}]);



