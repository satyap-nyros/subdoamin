


var app = angular.module('myApp', []);

// http://stackoverflow.com/questions/12864887/angularjs-integrating-with-server-side-validation

app.directive('uniqueUsername', ['$http', function($http) {
  return {
    require: 'ngModel',
    link: function(scope, elem, attrs, ctrl) {
      scope.busy = false;
      scope.$watch(attrs.ngModel, function(value) {
        
        // hide old error messages
        ctrl.$setValidity('isTaken', true);
        ctrl.$setValidity('invalidChars', true);
       
        if (!value) {
          // don't send undefined to the server during dirty check
          // empty username is caught by required directive
          return;
        }
      
        scope.busy = true;
        $http.post('application/index/validate', {'username' : value})
          .success(function(data) {
		console.log(data)
            // everything is fine -> do nothing
            scope.busy = false;
            if (data.invalidChars) {
              ctrl.$setValidity('invalidChars', false);
            }
          })          
      })
    }
  }
}]);

//Form submitting

app.controller('FormCtrl', function ($scope, $http) {

	//operations({'ID':1},"admin/session_check",$http,$scope);
  $scope.submitForm = function() {
    var formData = { 'username' : $scope.username,
                'password' : $scope.password};
      $http({
        url: "application/index/authenticate",
        data: formData,
        method: 'POST'
      }).success(function(data){

  
        if(data == 1)
        {
        
          $scope.error="Invalid Username/password";
           
        }
        if(data == 2)
        {
		
          window.location.href = '/superadmin';
        }

      }).error(function(err){"ERR", console.log(err)})
  };

});

app.controller('LgnCtrl', function ($scope, $http) {

	//operations({'ID':1},"admin/session_check",$http,$scope);
  $scope.submitForm = function() {
    var formData = { 'username' : $scope.username,
                'password' : $scope.password};
      $http({
        url: "login/index/authenticate",
        data: formData,
        method: 'POST'
      }).success(function(data){
console.log(data)
        
      if(data == 1)
        {
        
          $scope.error="Invalid Username/password";
           
        }
        else
        {
		
		if(parseInt(data.role) == 1)
		{
			 window.location.href = '/admin';
		}
		else
		{
			 window.location.href = '/clients';
		}
         
        }

      }).error(function(err){"ERR", console.log(err)})
  };

});



