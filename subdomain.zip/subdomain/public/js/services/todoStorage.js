/*global angular */

/**
 * Services that persists and retrieves TODOs from localStorage
 */
angular.module('todomvc')
	.factory('todoStorage', function ($resource,$http) {
		'use strict';

		var STORAGE_ID = 'todos-angularjs';
		var cnt=0;
		return {
			get: function () {
				
				
				/*$http.post('/clients/index/gettodos',{'pjid':$('#pjid').text()})
				  .success(function(data) {
					
					element[0] = data;			  
				  })*/
				var res = JSON.parse($.ajax({
				     type: 'POST',
				     url: '/clients/index/gettodos',
				     dataType: 'json',
				     global: false,
				     async:false,
				     data:{'pjid':$('#pjid').text()},
				     success: function(result) {
					return result;
				     }
				 }).responseText);
				for(var key in res )
					{						
						if(parseInt(res[key].completed) == 0)
						{
							res[key].completed = false;
						}
						else
						{
							res[key].completed = true;
						}
					}
				
				return res
				//return JSON.parse(localStorage.getItem(STORAGE_ID) || '[]');
			},

			put: function (todos,edit,del,mark,mrkal) {
				
				var url = '';var todo = {};var insert = 0;
				if(edit)
				{
					
					 url = '/clients/index/updatetodo';
					 todo = edit;
					 cnt = 0;
				}
				else if(del)
				{
					
					 url = '/clients/index/deletetodo';
					 todo = del;
					 cnt = 0;
				}
				else if(mark)
				{
					
					 url = '/clients/index/updatetodo';
					 cnt = 0;
					 todo = mark;					
				}
				else
				{
					if(mrkal == 1 || mrkal == 2)
					{						
						 cnt = 0;
						 url = '/clients/index/updtalltodos';
						 todo = todos;
					}
					else
					{
						insert = 1;					
					 	url = '/clients/index/todos';
					 	todo = todos[todos.length-1];
					}
					
				}
				
				
				if( cnt == 0 )
				{
				
				 $http.post(url, {'todos' : todo,'pjid':$('#pjid').text(),'markall': mrkal})
				  .success(function(data) {
					
					console.log(data)
					if(data==0)
					{					
						alert('error')
					}
					if(insert == 1)
					{						
					  todos[todos.length-1] = {completed: false,td_id: data,title: todo.title};
					  cnt++;
					}
								  
				  })
				}
				//localStorage.setItem(STORAGE_ID, JSON.stringify(todos));
			}
		};
	});
