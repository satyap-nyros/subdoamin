


var app = angular.module('myApp', []);

// http://stackoverflow.com/questions/12864887/angularjs-integrating-with-server-side-validation

app.directive('uniqueDomain', ['$http', function($http) {
  return {
    require: 'ngModel',
    link: function(scope, elem, attrs, ctrl) {
      
      scope.$watch(attrs.ngModel, function(value) {
        
        // hide old error messages
        ctrl.$setValidity('isTaken', true);
        ctrl.$setValidity('invalidChars', true);
       
        if (!value) {
          // don't send undefined to the server during dirty check
          // empty username is caught by required directive
          return;
        }
      
        scope.busy = true;
        $http.post('/application/index/validate', {'username' : value})
          .success(function(data) {
		
            // everything is fine -> do nothing
           
            if (data.invalidChars) {
              ctrl.$setValidity('invalidChars', false);
            }
          })          
      })
    }
  }
}]);



//Form submitting

app.controller('FormCtrl', function ($scope, $http) {
	
	
  $scope.editSubdomain = function() {
	if($scope.status)
	{
		$scope.status = 1;
	}
	else
	{
		$scope.status = 0;
	}
	
    	var formData = { 
		'sd_id' : $scope.id,
		'subdomain' : $scope.subdomain,
                'email' : $scope.email,
		'status' : $scope.status
		};
	
      $http({
        url: "/superadmin/index/edit",
        data: formData,
        method: 'POST'
      }).success(function(data){
		$scope.success = data;	
      }).error(function(err){"ERR", console.log(err)})
  };

});

app.directive('thisId', function ($http) {
  return {
    link: function ($scope, elem, attrs, ctrl) {

$http({
        url: "/superadmin/index/getthisdomain",
        data: {id : attrs.thisId},
        method: 'POST'
      }).success(function(data){
	
		$scope.id = data.sd_id;
		$scope.subdomain = data.subdomain;
		$scope.email = data.email;                
		$scope.status = data.status;
                
	});
    }
  }
});




