


var app = angular.module('myApp', []);

// http://stackoverflow.com/questions/12864887/angularjs-integrating-with-server-side-validation

app.directive('uniqueUsername', ['$http', function($http) {
  return {
    require: 'ngModel',
    link: function(scope, elem, attrs, ctrl) {
      
      scope.$watch(attrs.ngModel, function(value) {
        
        // hide old error messages
        ctrl.$setValidity('isTaken', true);
        ctrl.$setValidity('invalidChars', true);
       
        if (!value) {
          // don't send undefined to the server during dirty check
          // empty username is caught by required directive
          return;
        }
      
        scope.busy = true;
        $http.post('/application/index/validate', {'username' : value})
          .success(function(data) {
		
            // everything is fine -> do nothing
           
            if (data.invalidChars) {
              ctrl.$setValidity('invalidChars', false);
            }
          })          
      })
    }
  }
}]);

app.directive('match', [function () {
  return {
    require: 'ngModel',
    link: function (scope, elem, attrs, ctrl) {
      
      scope.$watch('[' + attrs.ngModel + ', ' + attrs.match + ']', function(value){
        ctrl.$setValidity('match', value[0] === value[1] );
      }, true);

    }
  }
}]);

//Form submitting

app.controller('FormCtrl', function ($scope, $http) {

	
  $scope.editUser = function() {
	
	if($scope.status)
	{
		$scope.status = 1;
	}
	else
	{
		$scope.status = 0;
	}
	var formData = {
			'id' : $scope.id, 
			'username' : $scope.username,
                	'email' : $scope.email,
                	'password' : $scope.password,
                	'first_name' : $scope.first_name,
                	'last_name' : $scope.last_name,
                	'mobile' : $scope.mobile,
                	'role' : $scope.role,
                	'user_group' : $scope.user_group,
			'status' : $scope.status
			};
	
	
    $http({
        url: "/admin/index/edit",
        data: formData,
        method: 'POST'
      }).success(function(data){
		console.log(data)
        if(data == 1)
	{
		$scope.error = "Username/email already existed";
		$scope.success = "";
	}	
	else
	{
		$scope.error = "";
		$scope.success = "User updated successfully";
	}
	
      }).error(function(err){"ERR", console.log(err)})
  };

});



app.directive('match', [function () {
  return {
    require: 'ngModel',
    link: function (scope, elem, attrs, ctrl) {
      
      scope.$watch('[' + attrs.ngModel + ', ' + attrs.match + ']', function(value){
        ctrl.$setValidity('match', value[0] === value[1] );
      }, true);

    }
  }
}]);

app.directive('thisId', function ($http) {
  return {
    link: function ($scope, elem, attrs, ctrl) {

     $http({
        url: "/admin/index/getthisuser",
        data: {id : attrs.thisId},
        method: 'POST'
      }).success(function(data){
		$scope.id = data.id;
		$scope.username = data.username;
		$scope.email = data.email;
                $scope.password = data.password;
		$scope.verification = data.password;
                $scope.first_name = data.first_name;
                $scope.last_name = data.last_name;
                $scope.mobile = data.mobile;
                $scope.role = data.role;
                $scope.user_group = data.user_group;
		$scope.status = data.status;
                
	});
    }
  }
});

app.directive('isNumber', function () {
	return {
		require: 'ngModel',
		link: function (scope) {	
			scope.$watch('mobile', function(newValue,oldValue) {
	
                var arr = String(newValue).split("");

                if (arr.length === 0) return;
                if (arr.length === 1 && (arr[0] == '-' || arr[0] === '.' )) return;
                if (arr.length === 2 && newValue === '-.') return;
                if (isNaN(newValue)) {
                    scope.mobile = oldValue;
                }
            });
		}
	};
});



