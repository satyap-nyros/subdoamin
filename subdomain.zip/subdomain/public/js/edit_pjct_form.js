


var app = angular.module('myApp', []);

// http://stackoverflow.com/questions/12864887/angularjs-integrating-with-server-side-validation






//Form submitting

app.controller('FormCtrl', function ($scope, $http) {

	

	$scope.value = [];
	
   $scope.updateQuestionValue = function(choice){	
	if($("input[type='checkbox'][name='group_one[]']:checked").length)
	{
		$scope.value = $scope.value.push(1);
	}
	else
	{
		$scope.value = [];
	}  
    };

	$scope.users = {};
  $scope.editProject = function() {
	
	if($scope.status)
	{
		$scope.status = 1;
	}
	else
	{
		$scope.status = 0;
	}
	var formData = {
			'id' : $scope.id, 
			'name' : $scope.name,
                	'usergroup' : $scope.usergroup,                	
                	'type' : $scope.type,                	
			'status' : $scope.status,
			'mail_clients' : ''
			};
		
	if($scope.type == 2)
	{
		
		var str='';
		for (key in $scope.users) {
			if($scope.users[key])
			{
			str = key+','+str;
			}
		    }
		formData.users = str;
		
	}
	
	
    $http({
        url: "/admin/index/updatepjct",
        data: formData,
        method: 'POST'
      }).success(function(data){
		console.log(data)
        if(data == 2)
	{
		$scope.error = "Project Name already existed";
		$scope.success = "";
	}
	else
	{
		$scope.error = "";
		$scope.success = "Project updated successfully";
	}
	
      }).error(function(err){"ERR", console.log(err)})
  };

	$scope.groupshow = function(){

		$http({
				url: "/admin/index/addproject",
				data: {'usergroup':$scope.usergroup},
				method: 'POST'
			      }).success(function(data){
					
					$scope.value = [];
					$scope.userslist = data;
					
					//scope.isselected = false;
				});
	
	}

});

app.directive('listshow', ['$http',function ($http) {

  return {
    require: 'ngModel',
    link: function (scope, elem, attrs, ctrl) {
    scope.$watch('type', function(value) {
			
		if(value == 2)
		{
			ctrl.$setValidity('match', true );
			$http({
				url: "/admin/index/addproject",
				data: {'usergroup':scope.usergroup},
				method: 'POST'
			      }).success(function(data){
					
					if(scope.chusers)
					{
						var fstr = scope.chusers;
						var arr = (fstr.slice(0, -1)).split(',');
						var count = 0;
						for($i=0;$i<data.length;$i++)
						{
						   for(key in arr)
						   {
						      if(parseInt(arr[key]) == parseInt(data[$i].id))
						      {
							
							scope.users[arr[key]] =true;
							data[$i].yes = 1; 
							count++;
						      }						      
						   }
						}
						scope.value = count;				
					}
					
					//scope.chusers = [];
					scope.userslist = data;
					
					
				});
			scope.isselected = true;
		}
		else
		{
			//scope.userslist = null;
			scope.isselected = false;
		}
	});

    }
  }
}]);

app.directive('thisid', function ($http) {

  return {
    link: function ($scope, elem, attrs, ctrl) {

     $http({
        url: "/admin/index/getthispjct",
        data: {id : attrs.thisid},
        method: 'POST'
      }).success(function(data){
		$scope.chusers = [];
		$scope.id = data.pjId;
		$scope.name = data.name;
		$scope.usergroup = data.usergroup;
                $scope.type = data.type;		
		$scope.status = data.status;
		if(data.users)
		{			
			$scope.chusers = data.users;			
		}
		
	});
    }
  }
});





