/*global angular */

/**
 * The main TodoMVC app module
 *
 * @type {angular.Module}
 */
angular.module('todomvc', ['ngRoute','ngResource'])
	.config(function ($routeProvider) {
		'use strict';

		$routeProvider.when('/', {
			controller: 'TodoCtrl',
			templateUrl: '/templates/todomvc-index.html'
		}).when('/comments/:tdid', {
			controller: 'CmntCtrl',
			templateUrl: '/templates/todomvc-cmnt.html'
		})
	});
