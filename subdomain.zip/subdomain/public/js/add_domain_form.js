


var app = angular.module('myApp', []);

// http://stackoverflow.com/questions/12864887/angularjs-integrating-with-server-side-validation

app.directive('uniqueDomain', ['$http', function($http) {
  return {
    require: 'ngModel',
    link: function(scope, elem, attrs, ctrl) {
      
      scope.$watch(attrs.ngModel, function(value) {
        
        // hide old error messages
        ctrl.$setValidity('isTaken', true);
        ctrl.$setValidity('invalidChars', true);
       
        if (!value) {
          // don't send undefined to the server during dirty check
          // empty username is caught by required directive
          return;
        }
      
        scope.busy = true;
        $http.post('/application/index/validate', {'username' : value})
          .success(function(data) {
		
            // everything is fine -> do nothing
           
            if (data.invalidChars) {
              ctrl.$setValidity('invalidChars', false);
            }
          })          
      })
    }
  }
}]);



//Form submitting

app.controller('FormCtrl', function ($scope, $http) {
	
	//operations({'ID':1},"admin/session_check",$http,$scope);
  $scope.addSubdomain = function() {
	if($scope.status)
	{
		$scope.status = 1;
	}
	else
	{
		$scope.status = 0;
	}
	
    	var formData = { 'subdomain' : $scope.subdomain,
                'email' : $scope.email,
		'status' : $scope.status
		};
	
      $http({
        url: "/superadmin/index/add",
        data: formData,
        method: 'POST'
      }).success(function(data){
		console.log(data)
        if(data == 4)
	{
		$scope.success="Subdomain successfully added";
		 $scope.error="";
		
	}
	else if(data == 1)
	{
		$scope.error="Unable to create database";
		 $scope.success="";
	}
	else if(data == 2)
	{
			
		$scope.error="Unable to connect to DB";
		 $scope.success="";
	}
	else if(data == 6)
	{
		$scope.error="Subdomain/DB created but users table for subdomain not created";
		 $scope.success="";
	}
	else if(data == 5)
	{
		$scope.error="Subdomain/DB/table created but credentials for admin not created";
		 $scope.success="";
	}
	/*else if(data == 3)
	{
		$scope.error="Unable to create subdomain";
		 $scope.success="";
	}*/
	else if(data == 7)
	{
		$scope.error="Subdomain already existed";
		 $scope.success="";
	}
	else 
	{
		$scope.error="Subdomain created but db not created for this domain";
		 $scope.success="";
	}  
	
      }).error(function(err){"ERR", console.log(err)})
  };

});

function operations(data,url,$http,$scope)
{
	$http({
		url: url,
		data: data,
		method: 'POST'
	      }).success(function(res){			
			if(url == "admin/session_check")
			{
				if(res == 1)
				{
					 window.location.href = '/admin#/home';
				}
			}
		});
	return 1;
}



