<?php

$pieces = explode(".", $_SERVER['HTTP_HOST']);

if(count($pieces)>2)
{
	$db = 'host_'.$pieces[0];
}
else
{
	$db = 'subdomain';
}
//$db = 'host_nyros';
return array(
  'doctrine' => array(
    'connection' => array(
      'orm_default' => array(
        'driverClass' =>'Doctrine\DBAL\Driver\PDOMySql\Driver',
        'params' => array(
          'host'     => 'localhost',
          'port'     => '3306',
          'user'     => 'root',
          'password' => 'root',
          'dbname'   => $db,
	)
	)
)));
