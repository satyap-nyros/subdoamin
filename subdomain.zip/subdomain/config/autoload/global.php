<?php
/**
 * Global Configuration Override
 *
 * You can use this file for overriding configuration values from modules, etc.
 * You would place values in here that are agnostic to the environment and not
 * sensitive to security.
 *
 * @NOTE: In practice, this file will typically be INCLUDED in your source
 * control, so do not include passwords or other sensitive information in this
 * file.
 */


$pieces = explode(".", $_SERVER['HTTP_HOST']);

if(count($pieces)>2)
{
	$db = 'host_'.$pieces[0];
}
else
{
	$db = 'subdomain';
}
//$db = 'host_nyros';

return array(
   'db' => array(
      'driver'         => 'Pdo',
      'dsn'            => 'mysql:dbname='.$db.';host=localhost',
   ),
   'service_manager' => array(
      'factories' => array(
         'Zend\Db\Adapter\Adapter' => 'Zend\Db\Adapter\AdapterServiceFactory',
      ),
   ),   
    'module_layouts' => array(
        'Application' => 'layout/layout',
        'Superadmin' => 'layout/sa_layout',
	'Login' => 'layout/log_layout',
	'Admin' => 'layout/ad_layout',
	'Clients' => 'layout/hm_layout',
    ),

);
